#!/bin/bash
# Trinity Symphony GitHub Labels Setup Script (v2 - Improved)
# 
# Usage: ./setup-labels.sh [OWNER/REPO]
# Example: ./setup-labels.sh hyperdag/trinity-ecosystem
#
# This script will:
# 1. Try using gh CLI if available
# 2. Fall back to GitHub API with token if gh not available
# 3. Generate a curl script if neither works

set -e

REPO=${1:-""}

if [ -z "$REPO" ]; then
    echo "Usage: ./setup-labels.sh OWNER/REPO"
    echo "Example: ./setup-labels.sh hyperdag/trinity-ecosystem"
    exit 1
fi

echo "🏷️  Trinity Symphony Label Setup for $REPO"
echo "==========================================="
echo ""

# Check if gh CLI is available
if command -v gh &> /dev/null; then
    echo "✅ GitHub CLI (gh) found. Using gh for label creation."
    USE_GH=true
elif [ -n "$GITHUB_TOKEN" ]; then
    echo "⚠️  GitHub CLI not found, but GITHUB_TOKEN is set."
    echo "   Using GitHub API directly."
    USE_GH=false
else
    echo "❌ GitHub CLI (gh) not found and GITHUB_TOKEN not set."
    echo ""
    echo "Options to proceed:"
    echo "1. Install gh CLI: https://cli.github.com/"
    echo "2. Set GITHUB_TOKEN environment variable"
    echo "3. Use the generated curl script (see below)"
    echo ""
    echo "Generating curl script for manual execution..."
    
    # Generate curl script
    cat > setup-labels-curl.sh << 'CURL_SCRIPT'
#!/bin/bash
# Run this script with: GITHUB_TOKEN=your_token ./setup-labels-curl.sh OWNER/REPO

REPO=$1
TOKEN=$GITHUB_TOKEN

if [ -z "$TOKEN" ] || [ -z "$REPO" ]; then
    echo "Usage: GITHUB_TOKEN=your_token ./setup-labels-curl.sh OWNER/REPO"
    exit 1
fi

create_label() {
    curl -s -X POST \
        -H "Authorization: token $TOKEN" \
        -H "Accept: application/vnd.github.v3+json" \
        "https://api.github.com/repos/$REPO/labels" \
        -d "{\"name\":\"$1\",\"color\":\"$2\",\"description\":\"$3\"}" > /dev/null
    echo "Created: $1"
}

# Agent labels
create_label "author:claude" "D4A574" "Work authored by Claude"
create_label "author:gemini" "4285F4" "Work authored by Gemini"
create_label "author:grok" "1DA1F2" "Work authored by Grok"
create_label "verifier:claude" "D4A574" "Claude assigned as verifier"
create_label "verifier:gemini" "4285F4" "Gemini assigned as verifier"
create_label "verifier:grok" "1DA1F2" "Grok assigned as verifier"

# Workflow labels
create_label "handoff" "7057FF" "Cross-agent task transfer"
create_label "verification" "0E8A16" "Requires cross-agent verification"
create_label "heterogeneous-protocol" "FBCA04" "Multi-LLM coordination"
create_label "protocol-violation" "B60205" "Heterogeneous Protocol violated"

# Status labels
create_label "blocked" "D93F0B" "Cannot proceed"
create_label "in-progress" "0052CC" "Currently being worked on"
create_label "needs-review" "FBCA04" "Ready for verification"
create_label "approved" "0E8A16" "Verified and approved"

# Priority labels
create_label "critical" "B60205" "Production incident"
create_label "high-priority" "D93F0B" "Important"
create_label "low-priority" "C2E0C6" "Nice to have"

# Type labels
create_label "bug" "D73A4A" "Something broken"
create_label "enhancement" "A2EEEF" "New feature"
create_label "documentation" "0075CA" "Docs changes"
create_label "sprint-task" "7057FF" "Sprint work item"
create_label "decision" "D4C5F9" "ADR"
create_label "triage" "D876E3" "Needs assessment"

# Squad labels
create_label "squad:orchestration" "5319E7" "ORCH, W3C, SHOFET"
create_label "squad:alpha" "1D76DB" "Truth squad"
create_label "squad:beta" "0E8A16" "Care squad"
create_label "squad:gamma" "D93F0B" "Build squad"

# Phase labels
create_label "phase:0" "BFD4F2" "Foundation"
create_label "phase:1" "C5DEF5" "Core dev"
create_label "phase:2" "D4E1F5" "Integration"

echo "✅ All labels created!"
CURL_SCRIPT

    chmod +x setup-labels-curl.sh
    echo ""
    echo "Generated: setup-labels-curl.sh"
    echo "Run with: GITHUB_TOKEN=your_token ./setup-labels-curl.sh $REPO"
    exit 0
fi

# Function to create label with gh or API
create_label() {
    local name="$1"
    local color="$2"
    local desc="$3"
    
    if [ "$USE_GH" = true ]; then
        gh label create "$name" --repo "$REPO" --description "$desc" --color "$color" --force 2>/dev/null || true
    else
        curl -s -X POST \
            -H "Authorization: token $GITHUB_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            "https://api.github.com/repos/$REPO/labels" \
            -d "{\"name\":\"$name\",\"color\":\"$color\",\"description\":\"$desc\"}" > /dev/null 2>&1 || true
    fi
    echo "  ✓ $name"
}

echo "Creating agent labels..."
create_label "author:claude" "D4A574" "Work authored by Claude"
create_label "author:gemini" "4285F4" "Work authored by Gemini/Antigravity"
create_label "author:grok" "1DA1F2" "Work authored by Grok"
create_label "verifier:claude" "D4A574" "Claude assigned as verifier"
create_label "verifier:gemini" "4285F4" "Gemini assigned as verifier"
create_label "verifier:grok" "1DA1F2" "Grok assigned as verifier"

echo "Creating workflow labels..."
create_label "handoff" "7057FF" "Cross-agent task transfer"
create_label "verification" "0E8A16" "Requires cross-agent verification"
create_label "heterogeneous-protocol" "FBCA04" "Multi-LLM coordination required"
create_label "protocol-violation" "B60205" "Heterogeneous Protocol violated - must fix"

echo "Creating status labels..."
create_label "blocked" "D93F0B" "Cannot proceed - needs intervention"
create_label "in-progress" "0052CC" "Currently being worked on"
create_label "needs-review" "FBCA04" "Ready for verification"
create_label "approved" "0E8A16" "Verified and approved"

echo "Creating priority labels..."
create_label "critical" "B60205" "Production incident or blocker"
create_label "high-priority" "D93F0B" "Important - address soon"
create_label "low-priority" "C2E0C6" "Nice to have"

echo "Creating type labels..."
create_label "bug" "D73A4A" "Something isn't working"
create_label "enhancement" "A2EEEF" "New feature or improvement"
create_label "documentation" "0075CA" "Documentation changes"
create_label "sprint-task" "7057FF" "Current sprint work item"
create_label "decision" "D4C5F9" "Architectural decision record"
create_label "triage" "D876E3" "Needs initial assessment"

echo "Creating squad labels..."
create_label "squad:orchestration" "5319E7" "ORCH, W3C, SHOFET"
create_label "squad:alpha" "1D76DB" "TORCH, VERITAS, GCM (Truth)"
create_label "squad:beta" "0E8A16" "CHESED, MEL, APM (Care)"
create_label "squad:gamma" "D93F0B" "SOPHIA, NEXUS, HDM (Build)"

echo "Creating phase labels..."
create_label "phase:0" "BFD4F2" "Foundation phase"
create_label "phase:1" "C5DEF5" "Core development"
create_label "phase:2" "D4E1F5" "Integration phase"

echo ""
echo "✅ All labels created successfully!"
echo ""
echo "Next steps:"
echo "1. Verify labels at: https://github.com/$REPO/labels"
echo "2. Copy issue templates to .github/ISSUE_TEMPLATE/"
echo "3. Enable GitHub Actions workflow"
