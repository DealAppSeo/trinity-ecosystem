/**
 * Trinity Symphony GitHub Labels Setup
 * 
 * Usage: 
 *   GITHUB_TOKEN=your_token node setup-labels.mjs owner/repo
 * 
 * Or in code:
 *   import { setupLabels } from './setup-labels.mjs';
 *   await setupLabels('owner/repo', 'your_token');
 */

const LABELS = [
  // Agent Assignment Labels
  { name: "author:claude", color: "D4A574", description: "Work authored by Claude" },
  { name: "author:gemini", color: "4285F4", description: "Work authored by Gemini" },
  { name: "author:grok", color: "1DA1F2", description: "Work authored by Grok" },
  { name: "verifier:claude", color: "D4A574", description: "Claude assigned as verifier" },
  { name: "verifier:gemini", color: "4285F4", description: "Gemini assigned as verifier" },
  { name: "verifier:grok", color: "1DA1F2", description: "Grok assigned as verifier" },
  
  // Workflow Labels
  { name: "handoff", color: "7057FF", description: "Cross-agent task transfer" },
  { name: "verification", color: "0E8A16", description: "Requires cross-agent verification" },
  { name: "heterogeneous-protocol", color: "FBCA04", description: "Multi-LLM coordination" },
  { name: "protocol-violation", color: "B60205", description: "Heterogeneous Protocol violated" },
  
  // Status Labels
  { name: "blocked", color: "D93F0B", description: "Cannot proceed - needs intervention" },
  { name: "in-progress", color: "0052CC", description: "Currently being worked on" },
  { name: "needs-review", color: "FBCA04", description: "Ready for verification" },
  { name: "approved", color: "0E8A16", description: "Verified and approved" },
  
  // Priority Labels
  { name: "critical", color: "B60205", description: "Production incident or blocker" },
  { name: "high-priority", color: "D93F0B", description: "Important - address soon" },
  { name: "low-priority", color: "C2E0C6", description: "Nice to have" },
  
  // Type Labels
  { name: "bug", color: "D73A4A", description: "Something isn't working" },
  { name: "enhancement", color: "A2EEEF", description: "New feature or improvement" },
  { name: "documentation", color: "0075CA", description: "Documentation changes" },
  { name: "sprint-task", color: "7057FF", description: "Current sprint work item" },
  { name: "decision", color: "D4C5F9", description: "Architectural decision record" },
  { name: "triage", color: "D876E3", description: "Needs initial assessment" },
  
  // Squad Labels
  { name: "squad:orchestration", color: "5319E7", description: "ORCH, W3C, SHOFET" },
  { name: "squad:alpha", color: "1D76DB", description: "TORCH, VERITAS, GCM (Truth)" },
  { name: "squad:beta", color: "0E8A16", description: "CHESED, MEL, APM (Care)" },
  { name: "squad:gamma", color: "D93F0B", description: "SOPHIA, NEXUS, HDM (Build)" },
  
  // Phase Labels
  { name: "phase:0", color: "BFD4F2", description: "Foundation phase" },
  { name: "phase:1", color: "C5DEF5", description: "Core development" },
  { name: "phase:2", color: "D4E1F5", description: "Integration phase" },
];

async function createLabel(repo, token, label) {
  const [owner, repoName] = repo.split('/');
  const url = `https://api.github.com/repos/${owner}/${repoName}/labels`;
  
  try {
    // Try to create
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `token ${token}`,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: label.name,
        color: label.color,
        description: label.description,
      }),
    });
    
    if (response.status === 201) {
      return { success: true, action: 'created' };
    } else if (response.status === 422) {
      // Label exists, try to update
      const updateUrl = `${url}/${encodeURIComponent(label.name)}`;
      const updateResponse = await fetch(updateUrl, {
        method: 'PATCH',
        headers: {
          'Authorization': `token ${token}`,
          'Accept': 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          color: label.color,
          description: label.description,
        }),
      });
      
      if (updateResponse.ok) {
        return { success: true, action: 'updated' };
      }
    }
    
    const error = await response.json();
    return { success: false, error: error.message || 'Unknown error' };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

export async function setupLabels(repo, token) {
  console.log(`\n🏷️  Trinity Symphony Label Setup for ${repo}`);
  console.log('='.repeat(50));
  
  const results = { created: 0, updated: 0, failed: 0, errors: [] };
  
  // Process labels in batches to avoid rate limiting
  const BATCH_SIZE = 5;
  const BATCH_DELAY = 1000; // 1 second between batches
  
  for (let i = 0; i < LABELS.length; i += BATCH_SIZE) {
    const batch = LABELS.slice(i, i + BATCH_SIZE);
    
    const batchResults = await Promise.all(
      batch.map(label => createLabel(repo, token, label))
    );
    
    batch.forEach((label, idx) => {
      const result = batchResults[idx];
      if (result.success) {
        console.log(`  ✓ ${label.name} (${result.action})`);
        if (result.action === 'created') results.created++;
        else results.updated++;
      } else {
        console.log(`  ✗ ${label.name}: ${result.error}`);
        results.failed++;
        results.errors.push({ label: label.name, error: result.error });
      }
    });
    
    // Delay between batches (except for last batch)
    if (i + BATCH_SIZE < LABELS.length) {
      await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));
    }
  }
  
  console.log('\n' + '='.repeat(50));
  console.log(`✅ Created: ${results.created}`);
  console.log(`🔄 Updated: ${results.updated}`);
  if (results.failed > 0) {
    console.log(`❌ Failed: ${results.failed}`);
  }
  console.log(`\n📋 View labels: https://github.com/${repo}/labels`);
  
  return results;
}

// CLI execution
if (import.meta.url === `file://${process.argv[1]}`) {
  const repo = process.argv[2];
  const token = process.env.GITHUB_TOKEN;
  
  if (!repo) {
    console.error('Usage: GITHUB_TOKEN=xxx node setup-labels.mjs owner/repo');
    process.exit(1);
  }
  
  if (!token) {
    console.error('Error: GITHUB_TOKEN environment variable not set');
    console.error('Get a token at: https://github.com/settings/tokens');
    process.exit(1);
  }
  
  setupLabels(repo, token)
    .then(results => {
      process.exit(results.failed > 0 ? 1 : 0);
    })
    .catch(err => {
      console.error('Fatal error:', err);
      process.exit(1);
    });
}
